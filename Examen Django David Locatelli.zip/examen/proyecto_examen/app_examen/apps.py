from django.apps import AppConfig


class AppExamenConfig(AppConfig):
    name = 'app_examen'
